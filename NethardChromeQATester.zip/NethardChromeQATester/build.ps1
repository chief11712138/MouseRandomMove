$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    throw "未找到 python。请安装 64 位 Python 3.12+ 并加入 PATH。"
}

python -m pip install --upgrade pyinstaller
python -m PyInstaller `
    --noconfirm `
    --clean `
    --onefile `
    --windowed `
    --name "NethardChromeQATester" `
    --add-data "nethard_qa\frontend;nethard_qa\frontend" `
    main.py

Write-Host ""
Write-Host "构建完成：dist\NethardChromeQATester.exe"
