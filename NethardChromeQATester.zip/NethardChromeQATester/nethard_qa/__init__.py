"""Nethard Chrome QA Tester."""

__version__ = "2.0.0"
