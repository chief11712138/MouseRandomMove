(() => {
  "use strict";

  const zone = document.getElementById("interactionZone");
  const log = document.getElementById("eventLog");
  const badge = document.getElementById("connectionBadge");
  const focusValue = document.getElementById("focusValue");
  const typedBuffer = document.getElementById("typedBuffer");
  const pointerReadout = document.getElementById("pointerReadout");
  const clearButton = document.getElementById("clearButton");

  const counts = new Map([
    ["mousemove", 0],
    ["click", 0],
    ["wheel", 0],
    ["keydown", 0],
    ["focus", 0],
    ["blur", 0],
  ]);

  const counterElements = {
    mousemove: document.getElementById("countMousemove"),
    click: document.getElementById("countClick"),
    wheel: document.getElementById("countWheel"),
    keydown: document.getElementById("countKeydown"),
    focus: document.getElementById("countFocus"),
    blur: document.getElementById("countBlur"),
  };

  let typed = "";
  let lastMouseReport = 0;

  async function postEvent(type, details = {}) {
    try {
      const response = await fetch("/api/event", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type, details }),
        cache: "no-store",
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      badge.textContent = "已连接桌面端";
      badge.className = "badge connected";
    } catch (error) {
      badge.textContent = "桌面端连接失败";
      badge.className = "badge error";
    }
  }

  function record(type, details = {}) {
    if (counts.has(type)) {
      const next = counts.get(type) + 1;
      counts.set(type, next);
      counterElements[type].textContent = String(next);
    }

    const item = document.createElement("li");
    const time = document.createElement("time");
    time.textContent = new Date().toLocaleTimeString();
    const payload = Object.keys(details).length ? ` ${JSON.stringify(details)}` : "";
    item.append(time, document.createTextNode(`  ${type}${payload}`));
    log.prepend(item);
    while (log.children.length > 60) log.lastElementChild.remove();
    postEvent(type, details);
  }

  zone.addEventListener("mousemove", (event) => {
    pointerReadout.textContent = `x: ${event.clientX} / y: ${event.clientY}`;
    const now = performance.now();
    if (now - lastMouseReport < 90) return;
    lastMouseReport = now;
    record("mousemove", { x: event.clientX, y: event.clientY });
  });

  zone.addEventListener("click", (event) => {
    zone.focus({ preventScroll: true });
    record("click", { x: event.clientX, y: event.clientY, button: event.button });
  });

  zone.addEventListener("wheel", (event) => {
    event.preventDefault();
    record("wheel", { deltaX: event.deltaX, deltaY: event.deltaY });
  }, { passive: false });

  zone.addEventListener("keydown", (event) => {
    if (event.key.length === 1) {
      typed = (typed + event.key).slice(-80);
      typedBuffer.textContent = typed || "—";
    }
    record("keydown", { key: event.key, code: event.code });
  });

  zone.addEventListener("focus", () => {
    focusValue.textContent = "已获得";
    focusValue.classList.add("active");
    record("focus");
  });

  zone.addEventListener("blur", () => {
    focusValue.textContent = "未获得";
    focusValue.classList.remove("active");
    record("blur");
  });

  clearButton.addEventListener("click", async () => {
    for (const [name] of counts) {
      counts.set(name, 0);
      counterElements[name].textContent = "0";
    }
    typed = "";
    typedBuffer.textContent = "—";
    log.replaceChildren();
    await fetch("/api/reset", { method: "POST", cache: "no-store" });
  });

  postEvent("page_ready", {
    userAgent: navigator.userAgent,
    viewport: { width: window.innerWidth, height: window.innerHeight },
  });
})();
