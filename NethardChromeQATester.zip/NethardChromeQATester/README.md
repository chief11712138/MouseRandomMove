# Nethard Chrome QA Tester

面向 Windows 11 和 Hyper-V Windows 11 客户机的单窗口 Chrome 输入测试工具。

## 当前实现

- 枚举当前所有可见 Chrome 顶层窗口。
- 下拉框只显示窗口标题，不展示 HWND、进程 ID 或其他内部编号。
- 同名窗口显示为“同名窗口 1/2”等可读后缀。
- 每次运行只锁定一个 Chrome 窗口；不会广播到其他窗口。
- 运行期间禁止切换目标窗口。
- 目标窗口关闭、标题改变或离开测试页后立即停止。
- 支持鼠标移动、单击、滚轮和普通字母数字键盘测试。
- 配套页面在 `127.0.0.1` 上运行，记录并回传浏览器事件。
- 桌面端对每次动作进行页面事件确认并写入 CSV 日志。

## 安全范围

程序会列出所有可见 Chrome 窗口，便于辨认窗口名称，但只允许向标题包含：

```text
Nethard QA Input Test
```

的配套本地测试页面发送输入。普通网页、登录页面、工作平台和第三方应用不会接收测试指令。

## 项目结构

```text
main.py
nethard_qa/
  app.py                     Tkinter 桌面界面
  config.py                  配置验证
  controller.py              单窗口运行控制器
  chrome_launcher.py         Chrome 启动
  event_log.py               CSV 审计日志
  paths.py                   源码/EXE 资源路径
  win32/
    chrome_windows.py        Chrome 窗口枚举与可读标题
    input_sender.py          Win32 输入发送
    dpi.py                   Win11 DPI 适配
  web/
    server.py                本地 HTTP/API 服务
  frontend/
    index.html               配套检测页面
    styles.css               页面样式
    app.js                   事件检测与回传
tests/
  test_config.py
  test_window_labels.py
build.ps1
run.bat
```

## Windows 11 运行

1. 安装 64 位 Python 3.12 或更新版本，安装时勾选 `Add python.exe to PATH`。
2. 解压项目。
3. 双击 `run.bat`，或运行：

```powershell
python main.py
```

4. 点击“打开配套测试页”。
5. 点击“刷新列表”，在下拉框选择 `Nethard QA Input Test - Google Chrome`。
6. 先点击“发送一次”检查动作和页面确认，再启动连续测试。

## 打包 EXE

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\build.ps1
```

输出：

```text
dist\NethardChromeQATester.exe
```

## Hyper-V 注意事项

- 宿主与客户机都使用 Win11 时，输入只发生在客户机桌面会话中。
- 客户机必须保持解锁，且不能处于暂停、保存或睡眠状态。
- 建议使用增强会话模式和 100%–150% 显示缩放。
- 程序会将选定 Chrome 窗口激活到前台后再发送动作。
- 不需要管理员权限、外网访问或浏览器扩展。
- Chrome 窗口过小会拒绝执行，以避免点击浏览器工具栏。

## 日志

默认位置：

```text
%LOCALAPPDATA%\NethardChromeQATester\logs
```
